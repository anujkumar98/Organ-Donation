/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Business.Organizations;

/**
 *
 * @author anujkumar
 */
public class HospitalPathology extends Organization{
    
    public HospitalPathology(String name){
        
        super(name);
    }
    
    
}
